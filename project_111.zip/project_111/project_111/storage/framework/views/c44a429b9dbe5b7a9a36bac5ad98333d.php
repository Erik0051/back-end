
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<?php echo $__env->make('../layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>User Profile</h3>
                </div>

                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <?php if($user->avatar): ?>
                                <img src="<?php echo e(asset('storage/' . $user->avatar)); ?>" class="img-fluid rounded-circle" width="150">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/150" class="img-fluid rounded-circle" width="150">
                            <?php endif; ?>
                        </div>

                        <div class="col-md-8">
                            <h4><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h4>
                            <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($user->phone); ?></p>
                            <p><strong>Biography:</strong></p>
                            <p><?php echo e($user->biography ?? 'No biography available.'); ?></p>
                        </div>
                    </div>
                    <a href="<?php echo e(route('profile')); ?>" class="btn btn-primary">Edit Profile</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\project_111\project_111\resources\views/home.blade.php ENDPATH**/ ?>