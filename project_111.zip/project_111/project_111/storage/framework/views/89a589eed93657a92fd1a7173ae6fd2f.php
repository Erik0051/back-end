<div id="images-container" class="row">
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-4">
            <div class="card">
                <img src="<?php echo e(asset('storage/' . $image->image)); ?>" class="card-img-top" alt="Image">
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\xampp\htdocs\project_111\project_111\resources\views////photos.blade.php ENDPATH**/ ?>