<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyApp</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<style>
        .hidden { display: none; }
    </style>
<body>
    
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">MyApp</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('profile')); ?>">Profile</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">my accaunt</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('images')); ?>">Home</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <div class="container mt-5">
        <h3 class="mb-4">Upload and View Your Images</h3>


        <div class="mb-4">
            <form id="imageUploadForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="input-group">
                    <input type="file" id="imageInput" name="image" class="form-control">
                    <button type="submit" class="btn btn-primary">Upload Image</button>
                </div>
            </form>
        </div>

    
        <div id="images-container" class="row">
            <?php echo $__env->make('photos', ['images' => $images], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

       
        <div id="pagination-links" class="mt-4">
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <?php echo e($images->links()); ?>

        </ul>
    </nav>
</div>
        
    </div>
    <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>

    <script>
    $(document).ready(function () {
    
        $('#imageUploadForm').on('submit', function(e) {
            e.preventDefault();
            
            let formData = new FormData(this);
            
            $.ajax({
                url: '<?php echo e(route("images.upload")); ?>',
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                   
                    $('#images-container').prepend(`
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <img src="/storage/${response.image.image}" class="card-img-top" alt="Image">
                            </div>
                        </div>
                    `);
                    $('#imageInput').val('');
                }
            });
        });

    
        $(document).on('click', '.pagination a', function(e) {
            e.preventDefault();
            
            let page = $(this).attr('href').split('page=')[1];
            loadImages(page);
        });

      
        function loadImages(page) {
            $.ajax({
                url: "<?php echo e(route('images')); ?>?page=" + page,
                success: function(data) {
                   
                    $('#images-container').html(data.view);
                   $('#pagination-links').html(data.pagination);
                }
            });
        }
    });
    </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\project_111\project_111\resources\views/images.blade.php ENDPATH**/ ?>