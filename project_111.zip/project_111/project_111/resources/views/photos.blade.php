<div id="images-container" class="row">
    @foreach ($images as $image)
        <div class="col-md-3 mb-4">
            <div class="card">
                <img src="{{ asset('storage/' . $image->image) }}" class="card-img-top" alt="Image">
            </div>
        </div>
    @endforeach
</div>

