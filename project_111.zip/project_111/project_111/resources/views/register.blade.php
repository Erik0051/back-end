
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="{{ url('/') }}">MyApp</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                @auth
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('profile') }}">Profile</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="{{ route('home') }}">my accaunt</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="{{ route('login') }}">Login</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="{{ route('register') }}">Register</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('images') }}">home</a>
                    </li>
                @endauth
            </ul>
        </div>
    </div>
</nav>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>




    @if(session('success'))
        <div style="color: green;">
            {{ session('success') }}
        </div>
    @endif

    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="card shadow-sm" style="max-width: 600px; width: 100%;">
            <div class="card-body">
                <h5 class="card-title text-center mb-4">Register</h5>
                <form action="{{ route('register.submit') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    
              
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" id="email" class="form-control" required value="{{ old('email') }}">
                        @error('email') 
                            <div class="text-danger">{{ $message }}</div> 
                        @enderror
                    </div>

                 
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" name="password" id="password" class="form-control" required>
                        @error('password') 
                            <div class="text-danger">{{ $message }}</div> 
                        @enderror
                    </div>

                
                    <div class="mb-3">
                        <label for="first_name" class="form-label">First Name</label>
                        <input type="text" name="first_name" id="first_name" class="form-control" required value="{{ old('first_name') }}">
                        @error('first_name') 
                            <div class="text-danger">{{ $message }}</div> 
                        @enderror
                    </div>

       
                    <div class="mb-3">
                        <label for="last_name" class="form-label">Last Name</label>
                        <input type="text" name="last_name" id="last_name" class="form-control" required value="{{ old('last_name') }}">
                        @error('last_name') 
                            <div class="text-danger">{{ $message }}</div> 
                        @enderror
                    </div>

                
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="number" name="phone" id="phone" class="form-control" value="{{ old('phone') }}">
                        @error('phone') 
                            <div class="text-danger">{{ $message }}</div> 
                        @enderror
                    </div>

                
                    <div class="mb-3">
                        <label for="biography" class="form-label">Biography</label>
                        <textarea name="biography" id="biography" class="form-control">{{ old('biography') }}</textarea>
                        @error('biography') 
                            <div class="text-danger">{{ $message }}</div> 
                        @enderror
                    </div>

           
                    <div class="mb-3">
                        <label for="avatar" class="form-label">Avatar (optional)</label>
                        <input type="file" name="avatar" id="avatar" class="form-control" accept="image/*">
                        @error('avatar') 
                            <div class="text-danger">{{ $message }}</div> 
                        @enderror
                    </div>

                  
                    <button type="submit" class="btn btn-primary w-100">Register</button>
                </form>
            </div>
        </div>
    </div>

</body>
</html>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>