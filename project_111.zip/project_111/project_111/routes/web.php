<?php
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\UsersProfieController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ImageController;
use Illuminate\Support\Facades\Auth;


Route::get('/', function () {
    return view('welcome');
});
Route::get('home', function () {
    return view('home');
});
Route::get('login',function(){
    return view('login');
});
Route::get('register', function(){
return view('register');
});
Route::get('profile', function(){
    return view('profile');
});
Route::get('/home', [HomeController::class, 'index'])->name('home');
Route::get('login', [LoginController::class, 'ShowLoginForm'])->name('login');
Route::post('login',[LoginController::class, 'login'])->name('login');

Route::get('/register', [RegisterController::class, 'ShowRegisterForm'])->name('register');
Route::post('/register', [RegisterController::class, 'register'])->name('register.submit');
Route::get('/dashboard', [RegisterController::class, 'register'])->name('dashboard');

Route::get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');

Route::get('/profile', [UsersProfieController::class, 'edit'])->name('profile');
Route::post('/profile', [UsersProfieController::class, 'update'])->name('profile.update');


Route::middleware(['auth'])->group(function () {
    Route::post('/images/upload', [ImageController::class, 'upload'])->name('images.upload');
    Route::get('/images', [ImageController::class, 'loadImages'])->name('images');
    
});