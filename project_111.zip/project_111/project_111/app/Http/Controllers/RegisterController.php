<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function ShowRegisterForm(){
        return view('register');
    }

    public function register(Request $request){
        $request->validate([
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8',
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'phone' => 'required|integer',
            'biography' => 'required|string',
            'avatar' => 'nullable|image|mimes:jpg,png,jpeg,gif|max:2000',
        ]);

       
        $avatarPath = null;
        if ($request->hasFile('avatar')) {
            $avatarPath = $request->file('avatar')->store('avatars', 'public');
        }

        User::create([
            'email' => $request->email,
            'password' => Hash::make($request->password), 
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'phone' => $request->phone,
            'biography' => $request->biography,
            'avatar' => $avatarPath,
        ]);

     
        return redirect()->back();
    }
}
