<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class LoginController extends Controller
{
    public function ShowLoginForm(){

        return view('login');
    }

    public function Login(Request $request){
        $request->validate([
            'email'=>'required|email',
            'password'=>'required'
        ]);
        if (Auth::attempt($request->only('email', 'password'))) {
            return redirect()->intended('home'); 
        }
    }

    public function logout(){
        User::logout();
        return redirect('/login');
    }
    
}
