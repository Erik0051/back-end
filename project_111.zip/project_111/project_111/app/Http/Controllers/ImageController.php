<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Photo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class ImageController extends Controller
{
    public function upload(Request $request)
    {
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $imagePath = $request->file('image')->store('images', 'public');
      
        $image = new Photo();
        $image->image = $imagePath;
        $image->user_id = Auth::id();
        $image->save();

        return response()->json(['image' => $image], 201);
    }

    public function loadImages(Request $request)
    {
        $images = Photo::where('user_id', Auth::id())->latest()->paginate(10);
        $images = Photo::paginate(10);
        if ($request->ajax()) {
            $view = view('photos', compact('images'))->render();
            $pagination = $images->links()->render();
            
            return response()->json(['view' => $view, 'pagination' => $pagination]);
        }
        
        return view('images', compact('images'));




    }
    
    
}
