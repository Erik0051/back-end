<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Photo extends Model
{
   protected  $filable = ['user_id','image'];
 
}
